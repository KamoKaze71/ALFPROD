Imports C1.Web.C1WebGrid
Imports Wyeth.Alf.WyethDropdown
Imports Wyeth.Alf.CssStyles
Imports Wyeth.Utilities.NumberFormat

Public Class TargetApproval
    Inherits System.Web.UI.Page


#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents btn_show_targets As System.Web.UI.WebControls.Button
    Protected WithEvents ddSare As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddYear As System.Web.UI.WebControls.DropDownList
    Protected WithEvents MyGrid As C1.Web.C1WebGrid.C1WebGrid
    Protected WithEvents reportpanel As System.Web.UI.WebControls.Panel
    Protected WithEvents mybutton As Button

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.


        InitializeComponent()
      
        Me.EnableViewState = True
        MyGrid.EnableViewState = True

    End Sub

#End Region
    Dim Mytrageting As New Targeting



    'Public Delegate Sub MyButtonClick(ByVal sender As Object, ByVal e As System.EventArgs)
    'Public Event checkch As delegateEvent


    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here



        If Page.IsPostBack = True Then


        Else

            GetYearDD(ddYear, 2004, 0)
            GetAllSaReDD(ddSare, Session("country_id"))
            ddSare.SelectedValue = 1
            groupColumns()
            bindData()


        End If

      
    End Sub

    'Protected Overrides Sub LoadViewState(ByVal savedState As Object)

    '    MyBase.LoadViewState(savedState)

    '    If CollAdded = True Then
    '        groupColumns()
    '    Else

    '    End If


    'End Sub

    Private Sub bindData()

        SetGridStylesGroup(MyGrid)
        MyGrid.DataSource = Mytrageting.GetTaregtsForApproval(ddYear.SelectedValue, ddSare.SelectedValue)
        MyGrid.DataBind(True)

    End Sub

    Private Sub groupColumns()

        'With MyGrid


        '    Dim SalesValueColumn As New C1BoundColumn
        '    SalesValueColumn.DataField = ("percentage_value")
        '    SalesValueColumn.HeaderText = "Sales Value"
        '    SalesValueColumn.Aggregate = AggregateEnum.Sum
        '    '   .Columns.RemoveAt(.Columns.IndexOf(SalesValueColumn))

        '    Dim TargetValueColumn As New C1BoundColumn
        '    TargetValueColumn.DataField = ("target_value")
        '    TargetValueColumn.HeaderText = "Traget Value"
        '    TargetValueColumn.Aggregate = AggregateEnum.Sum
        '    '  .Columns.RemoveAt(.Columns.IndexOf(TargetValueColumn))

        '    Dim qColumn As New C1BoundColumn
        '    qColumn.DataField = ("qType")
        '    qColumn.GroupInfo.HeaderText = "{0}"
        '    qColumn.HeaderText = "Quarter"
        '    qColumn.Aggregate = AggregateEnum.None
        '    ' .Columns.RemoveAt(.Columns.IndexOf(qColumn))

        '    Dim CCColumn As New C1BoundColumn
        '    CCColumn.DataField = ("prod_cc_description")
        '    CCColumn.GroupInfo.HeaderText = "{0}"
        '    CCColumn.HeaderText = "Cost Center"
        '    CCColumn.Aggregate = AggregateEnum.None
        '    '.Columns.RemoveAt(.Columns.IndexOf(CCColumn))


        '    Dim TAPGColumn As New C1BoundColumn
        '    TAPGColumn.DataField = ("tapg_description")
        '    TAPGColumn.HeaderText = "TPG"
        '    TAPGColumn.GroupInfo.HeaderText = "{0}"
        '    TAPGColumn.Aggregate = AggregateEnum.None
        '    '.Columns.RemoveAt(.Columns.IndexOf(TAPGColumn))


        '    Dim VersionColumn As New C1BoundColumn
        '    VersionColumn.DataField = ("targ_version")
        '    VersionColumn.HeaderText = "Version"
        '    VersionColumn.Aggregate = AggregateEnum.None
        '    VersionColumn.GroupInfo.HeaderText = "Version: {0}"
        '    '.Columns.RemoveAt(.Columns.IndexOf(VersionColumn))


        '    Dim ApprovalColumn As New C1BoundColumn
        '    'ApprovalColumn.DataField =("Approval")
        '    ApprovalColumn.HeaderText = "Approval"
        '    ApprovalColumn.Aggregate = AggregateEnum.None
        '    '.Columns.RemoveAt(.Columns.IndexOf(ApprovalColumn))



        '    Dim ApprovalByColumn As New C1BoundColumn
        '    ApprovalByColumn.DataField = ("user_approval")
        '    ApprovalByColumn.HeaderText = "Approval by"
        '    ApprovalByColumn.Aggregate = AggregateEnum.Max
        '    '.Columns.RemoveAt(.Columns.IndexOf(ApprovalByColumn))

        '    Dim TapgIDByColumn As New C1BoundColumn
        '    TapgIDByColumn.DataField = ("tapg_id")
        '    TapgIDByColumn.HeaderText = "Approval by"
        '    TapgIDByColumn.Aggregate = AggregateEnum.None
        '    '.Columns.RemoveAt(.Columns.IndexOf(TapgIDByColumn))

        '    Dim SareIDColumn As New C1BoundColumn
        '    SareIDColumn.DataField = ("sare_id")
        '    SareIDColumn.HeaderText = "Approval by"
        '    SareIDColumn.Aggregate = AggregateEnum.None
        '    '.Columns.RemoveAt(.Columns.IndexOf(SareIDColumn))



        '    Dim ButtonColumn As New C1ButtonColumn
        '    ButtonColumn.CommandName = "Approve"
        '    ButtonColumn.ButtonType = ButtonColumnType.PushButton



        '    '.Columns.Insert(0, TAPGColumn)
        '    '.Columns.Insert(1, VersionColumn)
        '    '.Columns.Insert(2, CCColumn)
        '    '.Columns.Insert(3, qColumn)
        '    '.Columns.Insert(4, TargetValueColumn)
        '    '.Columns.Insert(5, SalesValueColumn)
        '    '.Columns.Insert(6, ApprovalColumn)
        '    '.Columns.Insert(7, ApprovalByColumn)
        '    '.Columns.Insert(8, TapgIDByColumn)
        '    '.Columns.Insert(9, SareIDColumn)
        '    ''.Columns.Insert(10, ButtonColumn)

        '    .Columns(0).Visible = False
        '    .Columns(1).Visible = False
        '    .Columns(2).Visible = False
        '    .Columns(3).Visible = True
        '    .Columns(4).Visible = True
        '    .Columns(5).Visible = True
        '    .Columns(6).Visible = True
        '    .Columns(7).Visible = False
        '    .Columns(8).Visible = False
        '    ' .Columns(9).Visible = True
        '    '   .Columns(10).Visible = True


        '    .Columns(0).GroupInfo.Position = GroupPositionEnum.Header
        '    .Columns(0).GroupInfo.OutlineMode = OutlineModeEnum.StartCollapsed

        '    .Columns(1).GroupInfo.Position = GroupPositionEnum.Header
        '    .Columns(1).GroupInfo.OutlineMode = OutlineModeEnum.StartCollapsed

        '    .Columns(2).GroupInfo.Position = GroupPositionEnum.Header
        '    .Columns(2).GroupInfo.OutlineMode = OutlineModeEnum.StartCollapsed

        '    .Columns(3).GroupInfo.Position = GroupPositionEnum.None
        '    .Columns(3).GroupInfo.OutlineMode = OutlineModeEnum.None

        '    .Columns(4).GroupInfo.Position = GroupPositionEnum.None
        '    .Columns(4).GroupInfo.OutlineMode = OutlineModeEnum.None

        '    .Columns(5).GroupInfo.Position = GroupPositionEnum.None
        '    .Columns(5).GroupInfo.OutlineMode = OutlineModeEnum.None

        '    .Columns(6).GroupInfo.Position = GroupPositionEnum.None
        '    .Columns(6).GroupInfo.OutlineMode = OutlineModeEnum.None

        '    .Columns(7).GroupInfo.Position = GroupPositionEnum.None
        '    .Columns(7).GroupInfo.OutlineMode = OutlineModeEnum.None

        '    '.Columns(8).GroupInfo.Position = GroupPositionEnum.None
        '    '.Columns(8).GroupInfo.OutlineMode = OutlineModeEnum.None

        '    '.Columns(9).GroupInfo.Position = GroupPositionEnum.None
        '    '.Columns(9).GroupInfo.OutlineMode = OutlineModeEnum.None

        '    .EnableViewState = True

        'End With

        'Me.CollAdded = True




    End Sub

    Private Sub btnGenRep_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_show_targets.Click
        bindData()
    End Sub
    Public Sub mygrid_itemcommand(ByVal sender As Object, ByVal e As C1.Web.C1WebGrid.C1CommandEventArgs) Handles MyGrid.ItemCommand
        Dim myvar As String
        myvar = sender.GetType.FullName.ToString
        bindData()
        Response.Write("test")
    End Sub

    Private Sub MyGrid_ItemCreated(ByVal sender As Object, ByVal e As C1.Web.C1WebGrid.C1ItemEventArgs) Handles MyGrid.ItemCreated



        Dim myCheck As New CheckBox
        Dim v_version As String
        Dim sare_id, tpg_id As Integer

        myCheck.AutoPostBack = True
        myCheck.EnableViewState = True
        myCheck.ID = "chk" & e.Item.ItemIndex

        AddHandler myCheck.CheckedChanged, New EventHandler(AddressOf ChangeApproval)
        AddHandler myCheck.DataBinding, New EventHandler(AddressOf CheckoxDatabind)


        ' test = e.Item.Attributes.Item("style")

        If e.Item.ItemType = C1.Web.C1WebGrid.C1ListItemType.GroupHeader Then



            If e.Item.Attributes.Item("nodelevel") = 1 Then

                ' remove Approval in header column
                e.Item.Cells(MyGrid.Columns.IndexOf(MyGrid.Columns.ColumnByName("user_approval")) - 3).Text = ""



            ElseIf e.Item.Attributes.Item("nodelevel") = 2 Then
                Dim mybutton As New WebControls.Button

                mybutton.Text = "Approve"
                mybutton.CssClass = "button"
                mybutton.EnableViewState = True
                mybutton.CommandName = "Click"
                mybutton.ID = "butt" & e.Item.ItemIndex
                '   mybutton = e.Item.Cells(MyGrid.Columns.IndexOf(MyGrid.Columns.ColumnByName("test")) - 3).FindControl("


                AddHandler mybutton.Click, New EventHandler(AddressOf MyButtonClick)


                '  Dim container As C1GridItem = CType(sender.BindingContainer, C1GridItem)

                'sare_id = container.DataItem("sare_id")
                'tpg_id = container.DataItem("tapg_id")
                'v_version = container.DataItem("version")

                'Mytrageting.CheckForApproval(ddYear.SelectedValue, sare_id, tpg_id, v_version)

                e.Item.Cells(MyGrid.Columns.IndexOf(MyGrid.Columns.ColumnByName("user_approval")) - 3).Controls.Add(myCheck)

                e.Item.Cells(MyGrid.Columns.IndexOf(MyGrid.Columns.ColumnByName("user_approval")) - 3).Controls.Add(mybutton)


            ElseIf e.Item.Attributes.Item("nodelevel") = 3 Then

                e.Item.Cells(MyGrid.Columns.IndexOf(MyGrid.Columns.ColumnByName("user_approval")) - 3).Controls.Add(myCheck)

                If e.Item.Cells(MyGrid.Columns.IndexOf(MyGrid.Columns.ColumnByName("user_approval")) - 3).Text.Trim <> "" Then
                    myCheck.Checked = True
                Else
                    myCheck.Checked = False
                End If
                myCheck.Enabled = True

            End If

        ElseIf e.Item.ItemType = C1ListItemType.Item Or e.Item.ItemType = C1ListItemType.AlternatingItem Then
            myCheck.Enabled = True
            e.Item.Cells(MyGrid.Columns.IndexOf(MyGrid.Columns.ColumnByName("user_approval"))).Controls.Add(myCheck)

        End If


    End Sub

    Public Sub ChangeApproval(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim myvar As String
        myvar = sender.GetType.FullName.ToString
        bindData()
        Response.Write("test")
    End Sub
    Public Sub MyButtonClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles mybutton.Click
        Dim myvar As String
        myvar = sender.GetType.FullName.ToString
        bindData()
        Response.Write("test")
    End Sub
    Private Sub CheckoxDatabind(ByVal sender As Object, ByVal e As System.EventArgs)
        'Create a new instance of a CheckBox. 
        Dim oCheckBox As CheckBox = CType(sender, CheckBox)
        Dim container As C1GridItem = CType(oCheckBox.NamingContainer, C1GridItem)
        'Evaluate the data from the Grid item and set the Checked property 
        ' appropriatly

        If container.DataItem("approval_bol").GetType.ToString = "System.DBNull" Then
            oCheckBox.Checked = False
        Else
            oCheckBox.Checked = CBool(container.DataItem("approval_bol"))
        End If

    End Sub


    Private Sub MyGrid_ItemDatabound(ByVal sender As Object, ByVal e As C1.Web.C1WebGrid.C1ItemEventArgs) Handles MyGrid.ItemDataBound
        MyNumberFormat(e.Item.Cells(MyGrid.Columns.IndexOf(MyGrid.Columns.ColumnByName("target_value"))), 2)
        MyNumberFormat(e.Item.Cells(MyGrid.Columns.IndexOf(MyGrid.Columns.ColumnByName("percentage_value"))), 2)
    End Sub

    Private Property CollAdded() As Boolean
        Get
            If ViewState("DynamicColumnAdded") = True Then
                Return True

            Else
                Return False

            End If
        End Get
        Set(ByVal Value As Boolean)
            ViewState("DynamicColumnAdded") = Value
        End Set
    End Property
End Class
